let script = document.createElement("script");
script.src = "foo.js";
document.body.appendChild(script);
