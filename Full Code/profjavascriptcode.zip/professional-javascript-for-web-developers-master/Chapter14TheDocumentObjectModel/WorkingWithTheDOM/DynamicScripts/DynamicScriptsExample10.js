loadScriptString("function sayHi(){alert('hi');}");
