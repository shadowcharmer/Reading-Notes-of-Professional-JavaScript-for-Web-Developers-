loadStyleString("body{background-color:red}");
