<style type="text/css">
body {
  background-color: red;
}
</style>
