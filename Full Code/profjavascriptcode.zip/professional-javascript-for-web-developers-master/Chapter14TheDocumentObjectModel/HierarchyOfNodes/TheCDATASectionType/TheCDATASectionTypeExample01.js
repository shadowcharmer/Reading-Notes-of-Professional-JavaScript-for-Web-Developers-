<div id="myDiv"><![CDATA[This is some content.]]></div>
