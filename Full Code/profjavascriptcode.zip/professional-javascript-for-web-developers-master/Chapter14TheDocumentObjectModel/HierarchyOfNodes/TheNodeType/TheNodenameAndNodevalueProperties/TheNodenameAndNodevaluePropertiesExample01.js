if (someNode.nodeType == 1){
  value = someNode.nodeName;   // will be the element's tag name
}
