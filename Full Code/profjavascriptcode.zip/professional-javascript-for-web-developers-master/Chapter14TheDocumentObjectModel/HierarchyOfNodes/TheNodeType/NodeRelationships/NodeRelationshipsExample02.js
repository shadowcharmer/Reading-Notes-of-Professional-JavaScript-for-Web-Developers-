let arrayOfNodes = Array.prototype.slice.call(someNode.childNodes,0);
