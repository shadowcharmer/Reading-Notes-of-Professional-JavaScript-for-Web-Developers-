let returnedNode = someNode.appendChild(newNode);
alert(returnedNode == newNode);         // true
alert(someNode.lastChild == newNode);   // true
