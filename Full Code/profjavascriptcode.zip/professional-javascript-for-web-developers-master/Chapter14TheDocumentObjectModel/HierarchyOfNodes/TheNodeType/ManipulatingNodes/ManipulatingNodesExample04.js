// replace first child
let returnedNode = someNode.replaceChild(newNode, someNode.firstChild);
           
// replace last child
returnedNode = someNode.replaceChild(newNode, someNode.lastChild);
