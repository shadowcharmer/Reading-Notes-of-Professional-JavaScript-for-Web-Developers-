// remove first child
let formerFirstChild = someNode.removeChild(someNode.firstChild);
           
// remove last child
let formerLastChild = someNode.removeChild(someNode.lastChild);
