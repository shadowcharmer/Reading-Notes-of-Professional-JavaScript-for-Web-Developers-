if (someNode.nodeType == Node.ELEMENT_NODE){
  alert("Node is an element.");
}
