let textNode = div.firstChild;  // or div.childNodes[0]
