div.firstChild.nodeValue = "Some other message";
