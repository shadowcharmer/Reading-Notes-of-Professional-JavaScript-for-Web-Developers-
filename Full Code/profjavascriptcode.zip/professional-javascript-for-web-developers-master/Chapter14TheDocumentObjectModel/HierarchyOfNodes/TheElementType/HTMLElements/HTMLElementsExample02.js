let div = document.getElementById("myDiv");
alert(div.id);         // "myDiv"
alert(div.className);  // "bd"
alert(div.title);      // "Body text"
alert(div.lang);       // "en"
alert(div.dir);        // "ltr"
