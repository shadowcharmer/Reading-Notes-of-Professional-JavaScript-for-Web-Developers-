<div id="myDiv" class="bd" title="Body text" lang="en" dir="ltr"></div>
