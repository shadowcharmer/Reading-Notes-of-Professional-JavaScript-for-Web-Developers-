div.mycolor = "red";
alert(div.getAttribute("mycolor"));   // null (except in Internet Explorer)
