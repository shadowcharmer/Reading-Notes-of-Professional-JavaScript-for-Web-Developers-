div.removeAttribute("class");
