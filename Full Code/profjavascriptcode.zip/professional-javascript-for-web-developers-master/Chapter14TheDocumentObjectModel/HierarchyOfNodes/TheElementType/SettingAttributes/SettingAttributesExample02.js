div.id = "someOtherId";
div.align = "left";
