<div id="myDiv" my_special_attribute="hello!"></div>
