let value = div.getAttribute("my_special_attribute");
