<div id="myDiv" align="left" my_special_attribute="hello"></div>
