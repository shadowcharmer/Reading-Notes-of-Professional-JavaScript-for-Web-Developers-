let div = document.getElementById("myDiv");
alert(div.tagName);  // "DIV"
alert(div.tagName == div.nodeName);   // true
