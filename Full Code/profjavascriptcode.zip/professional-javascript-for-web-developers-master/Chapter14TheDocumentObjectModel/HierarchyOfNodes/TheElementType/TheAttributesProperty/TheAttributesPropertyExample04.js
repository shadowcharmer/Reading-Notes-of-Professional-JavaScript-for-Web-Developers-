let oldAttr = element.attributes.removeNamedItem("id");
