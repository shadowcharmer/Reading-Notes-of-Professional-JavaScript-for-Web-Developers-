element.attributes.setNamedItem(newAttr);
