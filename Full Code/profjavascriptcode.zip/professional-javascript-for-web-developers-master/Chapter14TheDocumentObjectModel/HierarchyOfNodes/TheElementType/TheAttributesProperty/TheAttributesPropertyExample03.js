element.attributes["id"].nodeValue = "someOtherId";
