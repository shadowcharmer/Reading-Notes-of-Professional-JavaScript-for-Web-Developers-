let id = element.attributes.getNamedItem("id").nodeValue;
