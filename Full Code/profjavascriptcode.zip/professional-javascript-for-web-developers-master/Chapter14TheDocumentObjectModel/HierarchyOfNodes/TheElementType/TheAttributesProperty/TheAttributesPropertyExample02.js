let id = element.attributes["id"].nodeValue;
