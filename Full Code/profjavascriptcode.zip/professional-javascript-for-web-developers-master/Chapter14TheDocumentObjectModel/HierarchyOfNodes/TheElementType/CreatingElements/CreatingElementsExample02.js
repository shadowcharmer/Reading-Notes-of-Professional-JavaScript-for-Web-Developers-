div.id = "myNewDiv";
div.className = "box";
