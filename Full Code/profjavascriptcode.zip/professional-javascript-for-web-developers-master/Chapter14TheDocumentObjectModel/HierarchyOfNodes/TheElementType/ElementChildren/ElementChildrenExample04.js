let ul = document.getElementById("myList");
let items = ul.getElementsByTagName("li");
