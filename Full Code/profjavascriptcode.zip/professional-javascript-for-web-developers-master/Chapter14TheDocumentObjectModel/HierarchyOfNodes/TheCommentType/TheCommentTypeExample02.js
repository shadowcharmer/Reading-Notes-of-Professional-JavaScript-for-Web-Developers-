let div = document.getElementById("myDiv");
let comment = div.firstChild;
alert(comment.data);  // "A comment"
