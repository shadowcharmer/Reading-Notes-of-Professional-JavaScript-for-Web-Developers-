<div id="myDiv"><!-- A comment --></div>
