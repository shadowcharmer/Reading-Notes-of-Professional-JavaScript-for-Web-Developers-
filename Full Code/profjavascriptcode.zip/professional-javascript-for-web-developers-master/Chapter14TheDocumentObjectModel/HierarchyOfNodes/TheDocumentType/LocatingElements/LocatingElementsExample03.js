let div = document.getElementById("mydiv");  // null
