<img src="myimage.gif" name="myImage">
