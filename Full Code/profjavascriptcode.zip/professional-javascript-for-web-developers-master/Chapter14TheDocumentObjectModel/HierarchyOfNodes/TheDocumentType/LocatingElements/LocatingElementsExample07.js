let myImage = images.namedItem("myImage");
