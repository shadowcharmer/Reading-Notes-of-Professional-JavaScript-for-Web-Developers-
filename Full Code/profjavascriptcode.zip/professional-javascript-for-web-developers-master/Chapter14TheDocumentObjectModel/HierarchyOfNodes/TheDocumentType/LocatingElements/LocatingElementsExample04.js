let images = document.getElementsByTagName("img");
