let allElements = document.getElementsByTagName("*");
