let radios = document.getElementsByName("color");
