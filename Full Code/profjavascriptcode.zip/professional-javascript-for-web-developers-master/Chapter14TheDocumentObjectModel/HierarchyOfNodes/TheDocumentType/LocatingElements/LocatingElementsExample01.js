<div id="myDiv">Some text</div>
