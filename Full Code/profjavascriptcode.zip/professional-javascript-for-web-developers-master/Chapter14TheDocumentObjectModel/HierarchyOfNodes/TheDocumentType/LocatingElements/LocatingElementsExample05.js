alert(images.length);       // output the number of images
alert(images[0].src);       // output the src attribute of the first image
alert(images.item(0).src);  // output the src attribute of the first image
