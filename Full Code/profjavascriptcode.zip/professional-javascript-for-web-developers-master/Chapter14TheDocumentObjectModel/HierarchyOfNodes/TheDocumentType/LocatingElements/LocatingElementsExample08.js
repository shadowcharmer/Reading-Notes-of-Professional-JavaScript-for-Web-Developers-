let myImage = images["myImage"];
