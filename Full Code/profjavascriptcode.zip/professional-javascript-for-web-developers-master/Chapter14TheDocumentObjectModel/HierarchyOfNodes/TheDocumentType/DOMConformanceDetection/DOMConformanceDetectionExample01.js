let hasXmlDom = document.implementation.hasFeature("XML", "1.0");
