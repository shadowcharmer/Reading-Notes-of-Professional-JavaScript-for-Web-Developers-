// page from p2p.wrox.com
           
document.domain = "wrox.com";       // succeeds
           
document.domain = "nczonline.net";  // error!
