// get the complete URL
let url = document.URL;
           
// get the domain
let domain = document.domain;
           
// get the referrer
let referrer = document.referrer;
