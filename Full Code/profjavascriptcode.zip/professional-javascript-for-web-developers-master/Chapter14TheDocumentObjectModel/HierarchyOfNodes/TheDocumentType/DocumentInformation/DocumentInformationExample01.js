// get the document title
let originalTitle = document.title;
           
// set the document title
document.title = "New page title";
