let body = document.body;  // get reference to <body>
