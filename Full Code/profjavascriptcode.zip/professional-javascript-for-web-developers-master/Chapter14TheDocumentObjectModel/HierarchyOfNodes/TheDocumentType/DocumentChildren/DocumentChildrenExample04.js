let doctype = document.doctype;   // get reference to <!DOCTYPE>
