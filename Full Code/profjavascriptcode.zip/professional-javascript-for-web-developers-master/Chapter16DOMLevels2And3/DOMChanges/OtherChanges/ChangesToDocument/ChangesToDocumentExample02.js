let parentWindow = document.defaultView || document.parentWindow;
