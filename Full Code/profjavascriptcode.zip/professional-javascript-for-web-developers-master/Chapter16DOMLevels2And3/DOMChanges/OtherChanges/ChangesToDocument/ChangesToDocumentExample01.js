let newNode = document.importNode(oldNode, true);   // import node and all children
document.body.appendChild(newNode);
