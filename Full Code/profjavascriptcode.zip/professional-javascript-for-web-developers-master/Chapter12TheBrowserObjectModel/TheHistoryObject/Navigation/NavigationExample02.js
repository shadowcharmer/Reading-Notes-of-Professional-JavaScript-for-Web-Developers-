// go to nearest wrox.com page
history.go("wrox.com");
           
// go to nearest nczonline.net page
history.go("nczonline.net");
