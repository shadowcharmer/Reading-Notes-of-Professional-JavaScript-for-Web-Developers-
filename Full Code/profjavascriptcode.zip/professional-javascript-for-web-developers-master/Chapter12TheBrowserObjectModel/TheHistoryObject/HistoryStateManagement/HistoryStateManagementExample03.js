history.replaceState({newFoo: "newBar"}, "New title");
