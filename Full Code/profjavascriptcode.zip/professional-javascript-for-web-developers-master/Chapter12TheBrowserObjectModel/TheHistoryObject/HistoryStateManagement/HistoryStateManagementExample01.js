let stateObject = {foo:"bar"};

history.pushState(stateObject, "My title", "baz.html");
