window.location = "http://www.wrox.com";
location.href = "http://www.wrox.com";
