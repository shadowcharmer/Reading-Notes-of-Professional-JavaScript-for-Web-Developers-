location.reload();      // reload - possibly from cache
location.reload(true);  // reload - go back to the server
