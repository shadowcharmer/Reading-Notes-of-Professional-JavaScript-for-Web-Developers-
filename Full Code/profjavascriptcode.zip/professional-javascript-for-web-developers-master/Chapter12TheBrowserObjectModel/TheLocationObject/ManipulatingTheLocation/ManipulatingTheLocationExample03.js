// assume starting at http://www.wrox.com/WileyCDA/
           
// changes URL to "http://www.wrox.com/WileyCDA/#section1"
location.hash = "#section1";
           
// changes URL to "http://www.wrox.com/WileyCDA/?q=javascript"
location.search = "?q=javascript";
           
// changes URL to "http://www.yahoo.com/WileyCDA/"
location.hostname = "www.yahoo.com";
           
// changes URL to "http://www.yahoo.com/mydir/"
location.pathname = "mydir";
           
// changes URL to "http://www.yahoo.com:8080/WileyCDA/
Location.port = 8080;
