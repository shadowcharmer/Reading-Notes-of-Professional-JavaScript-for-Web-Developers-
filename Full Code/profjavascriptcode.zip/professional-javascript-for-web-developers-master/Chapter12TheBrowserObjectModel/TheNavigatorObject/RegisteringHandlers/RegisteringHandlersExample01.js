navigator.registerProtocolHandler("mailto", 
  "http://www.somemailclient.com?cmd=%s", 
  "Some Mail Client");
