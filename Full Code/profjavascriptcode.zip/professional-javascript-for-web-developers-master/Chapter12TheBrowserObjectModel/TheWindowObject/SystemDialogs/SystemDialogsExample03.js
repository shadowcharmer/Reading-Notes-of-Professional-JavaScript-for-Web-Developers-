// display print dialog
window.print();
           
// display find dialog
window.find();
