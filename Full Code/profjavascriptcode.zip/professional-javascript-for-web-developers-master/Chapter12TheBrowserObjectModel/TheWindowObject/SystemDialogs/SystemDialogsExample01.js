if (confirm("Are you sure?")) {
  alert("I'm so glad you're sure!");
} else {
   alert("I'm sorry to hear you're not sure.");
}
