let wroxWin = window.open("http://www.wrox.com/",
              "wroxWindow",
              "height=400,width=400,top=10,left=10,resizable=yes");
           
// resize it
wroxWin.resizeTo(500, 500);
           
// move it
wroxWin.moveTo(100, 100);
