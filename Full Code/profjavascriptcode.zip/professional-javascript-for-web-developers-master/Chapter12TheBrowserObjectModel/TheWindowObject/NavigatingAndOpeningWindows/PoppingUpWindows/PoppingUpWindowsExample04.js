wroxWin.close();
alert(wroxWin.closed);  // true
