      
setInterval(() => alert("Hello world!"), 10000);
