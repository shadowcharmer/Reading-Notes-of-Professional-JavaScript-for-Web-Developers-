// set the timeout
let timeoutId = setTimeout(() => alert("Hello world!"), 1000);
           
// cancel it
clearTimeout(timeoutId);
