// schedules an alert to show after 1 second
setTimeout(() => alert("Hello world!"), 1000);
