try {
  throw 'foo';
} catch (e) {
  // An error happened, but you don't care about the error object
}
