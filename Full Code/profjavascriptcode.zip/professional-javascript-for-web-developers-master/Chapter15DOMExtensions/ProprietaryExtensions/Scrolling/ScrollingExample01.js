// Make sure this element is visible only if it's not already
document.images[0].scrollIntoViewIfNeeded();
