alert(document.documentElement.contains(document.body));  // true
