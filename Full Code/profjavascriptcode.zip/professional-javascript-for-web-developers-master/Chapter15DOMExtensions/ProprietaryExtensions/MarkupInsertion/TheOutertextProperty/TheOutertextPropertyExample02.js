let text = document.createTextNode("Hello world!");
div.parentNode.replaceChild(text, div);
