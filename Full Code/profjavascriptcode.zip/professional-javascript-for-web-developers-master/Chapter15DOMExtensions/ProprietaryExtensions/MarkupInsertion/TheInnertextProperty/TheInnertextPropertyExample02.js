This is a paragraph with a list following it.
Item 1
Item 2
Item 3
