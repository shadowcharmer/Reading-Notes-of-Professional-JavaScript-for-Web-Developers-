div.innerText = "Hello & welcome, <b>\"reader\"!</b>";
