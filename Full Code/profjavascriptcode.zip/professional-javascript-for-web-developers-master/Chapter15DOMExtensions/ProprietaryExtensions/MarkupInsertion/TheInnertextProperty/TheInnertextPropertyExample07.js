div.innerText = div.innerText;
