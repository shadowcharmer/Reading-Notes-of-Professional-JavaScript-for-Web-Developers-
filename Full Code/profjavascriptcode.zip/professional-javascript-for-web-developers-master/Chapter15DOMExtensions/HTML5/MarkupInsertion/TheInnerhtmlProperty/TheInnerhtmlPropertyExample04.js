div.innerHTML = "Hello & welcome, <b>\"reader\"!</b>";
