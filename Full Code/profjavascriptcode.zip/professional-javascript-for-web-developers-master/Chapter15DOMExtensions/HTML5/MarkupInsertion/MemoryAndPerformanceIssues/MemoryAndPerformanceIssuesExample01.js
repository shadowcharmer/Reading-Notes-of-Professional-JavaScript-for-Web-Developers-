for (let value of values){
  ul.innerHTML += `<li>${value}</li>`;  // avoid!!
} 
