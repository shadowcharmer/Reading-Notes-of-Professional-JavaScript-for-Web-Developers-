let button = document.getElementById("myButton");
button.focus();
alert(document.hasFocus());  // true
