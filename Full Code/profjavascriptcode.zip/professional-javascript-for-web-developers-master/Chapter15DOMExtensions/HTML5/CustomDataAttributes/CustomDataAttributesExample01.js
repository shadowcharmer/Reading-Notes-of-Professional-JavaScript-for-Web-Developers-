<div id="myDiv" data-appId="12345" data-myname="Nicholas"></div>
