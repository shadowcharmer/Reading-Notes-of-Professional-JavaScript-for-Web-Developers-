// Get the body element
let body = document.querySelector("body");
                   
// Get the element with the ID "myDiv"
let myDiv = document.querySelector("#myDiv");
                   
// Get first element with a class of "selected"
let selected = document.querySelector(".selected");
                   
// Get first image with class of "button"
let img = document.body.querySelector("img.button");
