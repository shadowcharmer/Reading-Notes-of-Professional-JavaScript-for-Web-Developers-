if (document.body.matches ("body.page1")){
  // true
}
