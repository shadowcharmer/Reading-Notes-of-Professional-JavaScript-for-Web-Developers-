if (object.propertyInQuestion) {
  // use object.propertyInQuestion
}
