Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.7 
  (KHTML, like Gecko) Chrome/7.0.517.44 Safari/534.7
