Opera/9.80 (OS-or-CPU; Encryption; Language) Presto/PrestoVersion Version/Version
