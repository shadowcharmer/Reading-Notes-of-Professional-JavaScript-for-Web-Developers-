Opera/9.80 (Windows NT 6.1; U; en) Presto/2.6.30 Version/10.63
