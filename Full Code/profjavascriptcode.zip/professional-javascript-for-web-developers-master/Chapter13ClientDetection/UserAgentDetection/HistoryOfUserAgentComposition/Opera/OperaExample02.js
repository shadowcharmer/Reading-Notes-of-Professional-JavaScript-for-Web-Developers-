Opera/7.54 (Windows NT 5.1; U) [en]
