Opera/Version (OS-or-CPU; Encryption) [Language]
