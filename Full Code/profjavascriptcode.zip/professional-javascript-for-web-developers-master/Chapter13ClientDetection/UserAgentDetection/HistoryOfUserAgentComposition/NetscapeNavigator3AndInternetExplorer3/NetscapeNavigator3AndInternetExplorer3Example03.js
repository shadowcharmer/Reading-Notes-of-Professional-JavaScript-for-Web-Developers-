Mozilla/2.0 (compatible; MSIE Version; Operating System)
For example, Internet Explorer 3.02 running on Windows 95 had this user-agent string:
Mozilla/2.0 (compatible; MSIE 3.02; Windows 95)
