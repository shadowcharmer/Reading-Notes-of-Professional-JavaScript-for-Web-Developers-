Mozilla/5.0 (compatible; Konqueror/Version; OS-or-CPU)
