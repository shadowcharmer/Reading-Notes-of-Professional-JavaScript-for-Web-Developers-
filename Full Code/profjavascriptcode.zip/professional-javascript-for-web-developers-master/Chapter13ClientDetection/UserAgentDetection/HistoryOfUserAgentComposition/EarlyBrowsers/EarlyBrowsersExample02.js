Mozilla/Version [Language] (Platform; Encryption)
