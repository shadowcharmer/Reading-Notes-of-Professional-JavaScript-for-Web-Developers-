Mozilla/2.02 [fr] (WinNT; I)
