Mozilla/5.0 (Platform; Encryption; OS-or-CPU like Mac OS X; Language) 
  AppleWebKit/AppleWebKitVersion (KHTML, like Gecko) Version/BrowserVersion 
  Mobile/MobileVersion Safari/SafariVersion
