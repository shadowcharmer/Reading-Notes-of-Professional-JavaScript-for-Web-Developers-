Mozilla/5.0 (Linux; U; Android 2.2; en-us; Nexus One Build/FRF91) 
  AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1
