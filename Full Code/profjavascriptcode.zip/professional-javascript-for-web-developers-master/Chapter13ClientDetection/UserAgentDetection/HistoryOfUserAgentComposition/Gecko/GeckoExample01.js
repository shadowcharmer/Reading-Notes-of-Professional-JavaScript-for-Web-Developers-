Mozilla/MozillaVersion (Platform; Encryption; OS-or-CPU; Language; 
  PrereleaseVersion)Gecko/GeckoVersion 
  ApplicationProduct/ApplicationProductVersion
