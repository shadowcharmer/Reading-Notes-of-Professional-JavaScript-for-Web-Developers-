Mozilla/5.0 (Macintosh; U; PPC Mac OS X; en) AppleWebKit/522.15.5 
  (KHTML, like Gecko) Version/3.0.3 Safari/522.15.5
