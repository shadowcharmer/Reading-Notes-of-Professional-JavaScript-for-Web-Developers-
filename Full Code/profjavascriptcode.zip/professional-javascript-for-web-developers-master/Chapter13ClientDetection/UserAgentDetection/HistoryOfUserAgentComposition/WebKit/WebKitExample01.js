Mozilla/5.0 (Platform; Encryption; OS-or-CPU; Language) 
  AppleWebKit/AppleWebKitVersion (KHTML, like Gecko) Safari/SafariVersion
