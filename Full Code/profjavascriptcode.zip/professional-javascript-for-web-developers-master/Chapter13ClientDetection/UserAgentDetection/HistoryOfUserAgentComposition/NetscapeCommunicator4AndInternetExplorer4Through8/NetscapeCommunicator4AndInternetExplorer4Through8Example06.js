Mozilla/4.0 (compatible; MSIE 4.5; Mac_PowerPC)
