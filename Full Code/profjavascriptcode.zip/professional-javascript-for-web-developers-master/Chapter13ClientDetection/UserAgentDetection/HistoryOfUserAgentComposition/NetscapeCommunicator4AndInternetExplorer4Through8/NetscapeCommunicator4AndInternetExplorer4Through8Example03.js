Mozilla/4.79 (Win98; I)
