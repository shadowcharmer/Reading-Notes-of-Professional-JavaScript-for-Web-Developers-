Mozilla/4.0 (Win98; I)
