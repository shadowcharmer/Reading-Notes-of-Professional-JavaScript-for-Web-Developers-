Mozilla/4.0 (compatible; MSIE 4.0; Windows 98)
