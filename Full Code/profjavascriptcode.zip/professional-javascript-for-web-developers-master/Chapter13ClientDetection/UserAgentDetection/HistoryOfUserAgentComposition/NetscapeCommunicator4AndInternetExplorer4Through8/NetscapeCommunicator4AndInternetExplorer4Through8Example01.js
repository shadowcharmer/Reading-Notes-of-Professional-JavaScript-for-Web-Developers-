Mozilla/Version (Platform; Encryption [; OS-or-CPU description])
