console.log(p.timestamp);  // 1525364883361
console.log(p.coords);     // Coordinates {...}
