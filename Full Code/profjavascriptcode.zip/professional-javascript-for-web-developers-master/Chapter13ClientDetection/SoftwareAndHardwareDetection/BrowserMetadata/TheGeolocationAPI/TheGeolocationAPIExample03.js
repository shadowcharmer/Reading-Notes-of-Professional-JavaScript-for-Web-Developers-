console.log(p.coords.latitude, p.coords.longitude);  // 37.4854409, -122.2325506
console.log(p.coords.accuracy);                      // 58
