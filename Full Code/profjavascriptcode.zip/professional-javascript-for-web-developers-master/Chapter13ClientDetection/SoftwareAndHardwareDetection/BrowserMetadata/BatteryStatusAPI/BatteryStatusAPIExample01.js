navigator.getBattery().then((b) => console.log(b));
// BatteryManager { ... }
