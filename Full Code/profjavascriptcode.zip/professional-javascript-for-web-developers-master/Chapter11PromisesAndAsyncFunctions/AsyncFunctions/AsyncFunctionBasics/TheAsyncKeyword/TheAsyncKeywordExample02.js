async function foo() {
  console.log(1);
}

foo();
console.log(2);

// 1
// 2
