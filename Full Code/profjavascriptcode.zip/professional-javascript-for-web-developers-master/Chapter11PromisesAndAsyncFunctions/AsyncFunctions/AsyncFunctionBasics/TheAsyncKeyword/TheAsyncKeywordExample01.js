async function foo() {}

let bar = async function() {};

let baz = async () => {};

class Qux {
  async qux() {}
}
