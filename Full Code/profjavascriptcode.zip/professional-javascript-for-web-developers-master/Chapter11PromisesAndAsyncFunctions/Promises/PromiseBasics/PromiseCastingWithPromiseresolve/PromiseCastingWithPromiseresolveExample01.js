let p1 = new Promise((resolve, reject) => resolve());
let p2 = Promise.resolve();
