class MyThenable {
  then() {}
}
