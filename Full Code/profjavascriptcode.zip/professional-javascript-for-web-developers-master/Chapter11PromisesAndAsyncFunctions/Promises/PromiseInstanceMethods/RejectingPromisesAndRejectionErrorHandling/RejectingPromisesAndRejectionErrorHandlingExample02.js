throw Error('foo');
console.log('bar');  // This will never print

// Uncaught Error: foo
