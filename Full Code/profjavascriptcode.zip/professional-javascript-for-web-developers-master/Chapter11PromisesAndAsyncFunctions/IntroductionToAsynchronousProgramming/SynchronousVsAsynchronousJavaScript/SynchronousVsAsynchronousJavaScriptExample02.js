let x = 3; 
setTimeout(() => x = x + 4, 1000);
