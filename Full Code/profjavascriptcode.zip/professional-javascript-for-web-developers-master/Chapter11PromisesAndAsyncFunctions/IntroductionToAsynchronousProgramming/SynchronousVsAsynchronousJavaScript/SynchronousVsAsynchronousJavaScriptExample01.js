let x = 3; 
x = x + 4;
