// Use of the with statement
// Non-strict mode: Allowed
// Strict mode: Throws a syntax error
with(location) {
  alert(href);
}
