function doSomething() {
  "use strict";
  // other processing
}
