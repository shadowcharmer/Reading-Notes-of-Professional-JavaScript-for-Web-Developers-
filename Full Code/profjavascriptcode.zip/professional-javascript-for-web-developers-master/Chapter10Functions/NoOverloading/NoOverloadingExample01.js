function addSomeNumber(num) {
  return num + 100;
}
                   
function addSomeNumber(num) {
  return num + 200;
}
                   
let result = addSomeNumber(100);  // 300
