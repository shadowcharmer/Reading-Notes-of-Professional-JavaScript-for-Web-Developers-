(function() {
  // block code here
})();
