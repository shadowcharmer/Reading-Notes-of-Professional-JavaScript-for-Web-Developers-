function sayName(name) {
  console.log(name);
}      
                   
function sum(num1, num2) {
  return num1 + num2;
}
                   
function sayHi() {
  console.log("hi");
}
                   
console.log(sayName.length);  // 1
console.log(sum.length);      // 2
console.log(sayHi.length);    // 0
