function callSomeFunction(someFunction, someArgument) {
  return someFunction(someArgument);
}
