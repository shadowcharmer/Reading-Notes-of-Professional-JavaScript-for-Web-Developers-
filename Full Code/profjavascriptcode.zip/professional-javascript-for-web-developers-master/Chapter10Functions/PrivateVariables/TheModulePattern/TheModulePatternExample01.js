let singleton = {
  name: value,
  method() {
    // method code here
  }
};
