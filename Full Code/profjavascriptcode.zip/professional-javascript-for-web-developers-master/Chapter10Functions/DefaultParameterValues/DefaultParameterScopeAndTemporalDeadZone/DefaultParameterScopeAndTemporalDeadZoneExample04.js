// Error
function makeKing(name = numerals, numerals = 'VIII') {
  return `King ${name} ${numerals}`;
}
