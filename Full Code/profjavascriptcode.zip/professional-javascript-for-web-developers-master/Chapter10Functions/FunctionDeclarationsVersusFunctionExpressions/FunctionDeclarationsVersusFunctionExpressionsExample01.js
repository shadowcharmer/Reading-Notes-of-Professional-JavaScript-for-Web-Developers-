// OK
console.log(sum(10, 10));
function sum(num1, num2) {
  return num1 + num2;
}
