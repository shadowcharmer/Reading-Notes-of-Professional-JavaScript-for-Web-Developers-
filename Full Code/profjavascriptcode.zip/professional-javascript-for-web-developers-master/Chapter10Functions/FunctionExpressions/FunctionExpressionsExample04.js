sayHi();  // Error! function doesn't exist yet
let sayHi = function() {
  console.log("Hi!");
};
