console.log(getSum(...values));  // 10
