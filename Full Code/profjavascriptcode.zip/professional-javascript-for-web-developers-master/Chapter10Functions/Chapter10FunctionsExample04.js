let sum = new Function("num1", "num2", "return num1 + num2");   // not recommended
